/*
 *  Empty placeholder
 *
 *  Copyright The Mbed TLS Contributors
 *  SPDX-License-Identifier: Apache-2.0 OR GPL-2.0-or-later
 */

/*
 * This file is intentionally empty.
 *
 * Having an empty file here allows us to build the TF-M config, which references this file,
 * without making any changes to the TF-M config.
 */
