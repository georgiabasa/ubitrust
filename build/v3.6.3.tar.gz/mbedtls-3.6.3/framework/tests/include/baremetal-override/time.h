/*
 *  Copyright The Mbed TLS Contributors
 *  SPDX-License-Identifier: Apache-2.0 OR GPL-2.0-or-later
 */

#error "time.h included in a configuration without MBEDTLS_HAVE_TIME"
